"""Operator-side deployment: source -> bounded SCP -> real remote checks -> commit relay.

This helper is outside the application repository. It never reads credentials and
never deletes deployed files. Explicit paths control each publication boundary.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
import zipfile

sys.stdout.reconfigure(encoding='utf-8')

BASE = Path(__file__).resolve().parent
REPO = BASE / 'GazeboTeach'
SSH_CONFIG = 'C:/Users/z/.ssh/config'
SSH = 'C:/Windows/System32/OpenSSH/ssh.exe'
SCP = 'C:/Windows/System32/OpenSSH/scp.exe'
REMOTE = '/home/ikaros/GazeboTeach'
OPTIONS = ['-F', SSH_CONFIG, '-o', 'BatchMode=yes', '-o',
           'StrictHostKeyChecking=yes', '-o', 'ConnectTimeout=10']


def run(args, cwd=None, timeout=180, check=True):
    result = subprocess.run(args, cwd=str(cwd or REPO), timeout=timeout,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = result.stdout.decode('utf-8', errors='replace')
    if output:
        print(output, end='' if output.endswith('\n') else '\n', flush=True)
    if check and result.returncode:
        raise RuntimeError('Command exited {}: {}'.format(result.returncode, args[0]))
    return result.returncode, output


def remote(command, timeout=180, check=True):
    wrapper = '''import os,pathlib,subprocess,sys
env=os.environ.copy()
for entry in pathlib.Path('/proc').iterdir():
 try:
  if entry.name.isdigit() and entry.stat().st_uid==os.getuid() and (entry/'comm').read_text().strip()=='gnome-shell':
   values=dict(x.split('=',1) for x in (entry/'environ').read_bytes().decode('utf-8','replace').split('\\0') if '=' in x)
   for key in ('DISPLAY','XAUTHORITY','XDG_RUNTIME_DIR','DBUS_SESSION_BUS_ADDRESS'):
    if values.get(key): env.setdefault(key,values[key])
   break
 except (OSError,ValueError): pass
sys.exit(subprocess.call(['bash','--noprofile','--norc','-c',COMMAND],env=env))
'''.replace('COMMAND', repr(command))
    return run([SSH] + OPTIONS + ['ikaros', 'python3 -c ' + shlex.quote(wrapper)],
               timeout=timeout, check=check)


def deploy(paths):
    archive = BASE / 'gazeboteach-deploy.zip'
    count = 0
    with zipfile.ZipFile(str(archive), 'w', zipfile.ZIP_DEFLATED) as bundle:
        for value in paths:
            candidate = (REPO / value).resolve()
            if REPO.resolve() not in candidate.parents:
                raise ValueError('Path must stay inside repository: ' + value)
            items = sorted(candidate.rglob('*')) if candidate.is_dir() else [candidate]
            for item in items:
                if not item.is_file() or any(x in item.parts for x in ['__pycache__', '.git', 'build']):
                    continue
                bundle.write(str(item), item.relative_to(REPO).as_posix())
                count += 1
    remote('mkdir -p ' + REMOTE + '/.deploy')
    run([SCP] + OPTIONS + [str(archive), 'ikaros:' + REMOTE + '/.deploy/update.zip'])
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    remote('printf %s ' + shlex.quote(digest + '  ' + REMOTE + '/.deploy/update.zip\n') + ' | sha256sum -c -')
    extraction = '''import pathlib,zipfile,os
root=pathlib.Path("/home/ikaros/GazeboTeach").resolve()
with zipfile.ZipFile(str(root/".deploy/update.zip")) as z:
 for member in z.infolist():
  dest=(root/member.filename).resolve()
  if root not in dest.parents: raise RuntimeError("Archive outside deployment boundary")
  dest.parent.mkdir(parents=True,exist_ok=True)
  dest.write_bytes(z.read(member))
  if dest.suffix==".sh": dest.chmod(0o755)
print("DEPLOY_OK",len(z.infolist()))
'''
    remote('python3 -c ' + shlex.quote(extraction))
    print('Published {} files'.format(count), flush=True)


def relay():
    bundle = BASE / 'gazeboteach-current.bundle'
    run(['git', 'bundle', 'create', str(bundle), 'main'])
    run([SCP] + OPTIONS + [str(bundle), 'ikaros:' + REMOTE + '/.deploy/repository.bundle'])
    remote('cd ' + REMOTE + ' && git fetch .deploy/repository.bundle main && '
           'git reset --mixed FETCH_HEAD && git log -1 --oneline')


def github(arguments):
    """Retry idempotent Git IO, then use GitHub's official SSH-over-443 endpoint.

    Persistent auth/host identity errors stop immediately. The fallback keeps
    the existing github.com host-key identity and never changes global config.
    """
    commands = [(['git'] + arguments), (['git'] + arguments)]
    fallback = (SSH + ' -F ' + SSH_CONFIG +
                ' -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=10'
                ' -o HostName=ssh.github.com -p 443 -o HostKeyAlias=github.com'
                ' -o HostKeyAlgorithms=ssh-ed25519')
    commands.append(['git', '-c', 'core.sshCommand=' + fallback] + arguments)
    last = ''
    for index, command in enumerate(commands):
        if index:
            time.sleep(2)
            print('Retrying GitHub transport ({}/3)'.format(index+1), flush=True)
        code, output = run(command, timeout=90, check=False)
        if not code:
            return code, output
        last = output
        lowered = output.lower()
        if any(x in lowered for x in ['permission denied', 'host key verification failed',
                                      'remote host identification has changed', 'repository not found']):
            break
    raise RuntimeError('GitHub transport failed after bounded attempts: ' + last[-1200:])


def publish(paths, message):
    quoted = ' '.join(shlex.quote(p) for p in paths)
    remote('cd ' + REMOTE + ' && git add -- ' + quoted + ' && '
           'git diff --cached --stat && git commit -m ' + shlex.quote(message))
    run(['git', 'fetch', 'ikaros', 'main'], timeout=90)
    # A mixed reset adopts committed remote history without replacing parallel
    # local source drafts or the files that have just been copied for validation.
    run(['git', 'reset', '--mixed', 'FETCH_HEAD'])
    github(['push', 'origin', 'main'])
    _, current = run(['git', 'rev-parse', 'HEAD'])
    _, upstream = github(['ls-remote', 'origin', 'refs/heads/main'])
    if not upstream.strip().startswith(current.strip() + '\t'):
        raise RuntimeError('GitHub main does not match the validated commit')
    print('PUBLISH_VERIFIED ' + current.strip(), flush=True)


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    p = sub.add_parser('deploy'); p.add_argument('paths', nargs='+')
    p = sub.add_parser('run'); p.add_argument('command'); p.add_argument('--timeout', type=int, default=180)
    p = sub.add_parser('publish'); p.add_argument('-m', '--message', required=True); p.add_argument('paths', nargs='+')
    sub.add_parser('relay')
    args = parser.parse_args()
    if args.action == 'deploy': deploy(args.paths)
    elif args.action == 'run':
        code, output = remote(args.command, timeout=args.timeout, check=False)
        logs = BASE / 'runs'; logs.mkdir(exist_ok=True)
        (logs / ('remote-{}.log'.format(time.time_ns()))).write_text(output, encoding='utf-8')
        sys.exit(code)
    elif args.action == 'publish': publish(args.paths, args.message)
    elif args.action == 'relay': relay()


if __name__ == '__main__': main()
