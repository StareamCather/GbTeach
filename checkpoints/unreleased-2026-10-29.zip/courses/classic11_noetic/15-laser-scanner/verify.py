#!/usr/bin/env python3
import copy
import math
import time
from sensor_msgs.msg import LaserScan
from lab import init, sample, state, apply, report
init()
def center(m):
    index = int(round(-m.angle_min/m.angle_increment))
    return m.ranges[index]
cpu = sample('/lesson15/scan', LaserScan, lambda m: len(m.ranges)>=180 and math.isfinite(center(m)))
gpu = sample('/lesson15/gpu_scan', LaserScan, lambda m: len(m.ranges)>=180 and math.isfinite(center(m)))
assert abs(center(cpu)-2.9)<0.08, 'CPU中心束未测到2.9米墙面'
assert abs(center(gpu)-center(cpu))<0.08, 'CPU/GPU测距不一致'
original = state('target_wall')
try:
    moved = copy.deepcopy(original); moved.pose.position.x += 1.0; apply(moved)
    changed = sample('/lesson15/scan', LaserScan, lambda m: math.isfinite(center(m)) and abs(center(m)-3.9)<0.08)
    changed_gpu = sample('/lesson15/gpu_scan', LaserScan, lambda m: math.isfinite(center(m)) and abs(center(m)-3.9)<0.08)
    report(cpu_initial_m=center(cpu), gpu_initial_m=center(gpu), cpu_moved_m=center(changed), gpu_moved_m=center(changed_gpu), beams=len(cpu.ranges), frame=cpu.header.frame_id)
finally:
    apply(original)
