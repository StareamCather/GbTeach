# 15 激光扫描：距离如何变成数组

## 项目目标
一个固定扫描器面对黄色墙体，同时输出 CPU ray 和 GPU ray 两组扫描。中心束应测到约 2.9 m；把墙向远处移动 1 m 后，读数也应增加约 1 m。这一课把“数组是什么”与“场景真的改变了什么”连接起来。

## 必要背景
LaserScan 保存 angle_min、angle_increment 和 ranges。第 i 个测量的方向是 angle_min + i × angle_increment，单位为弧度；ranges[i] 是沿该束到第一个有效表面的距离，单位为米。超过量程可能返回无穷或边界值，不能直接对所有元素求平均。消息里的 frame_id 表示测量所属坐标系，TF 的建立将在第 24 课继续。

## 原理与信息流
CPU ray 使用物理碰撞几何进行射线检测，GPU ray 使用渲染场景深度等图形资源完成扫描。输入都是传感器位姿、角度采样和量程；输出经过 Gazebo ROS 激光插件成为 LaserScan。路径为：SDF 扫描参数 → 多方向射线/渲染采样 → 每束最近有效距离 → ROS 消息 → 数组分析。因此 visual 与 collision 不一致时，两类扫描可能出现不同结果。

## 文件与关键字段
`world.sdf` 内有两个同位姿传感器，类型分别为 ray、gpu_ray，使用对应的 Noetic 插件。horizontal/samples 为 181，扫描范围为正负 90 度；中心索引由角度计算，而不是假定永远取数组中点。`verify.py` 先检查两路读数，再通过本课 Gazebo 服务移动真实 target_wall，等待新读数，最后恢复原位置。它不会用预置数组代替扫描数据。

## 引导实验
1. 执行 `rostopic echo -n 1 /lesson15/scan`，预测中心束和斜向束哪个更长。
2. 执行 `rostopic hz /lesson15/scan`，区分配置更新率与实际接收频率。
3. 把 samples 改为 91，重启实验，检查角度增量和数组长度。
4. 只修改墙体 visual 的位置而保留 collision，比较两种扫描。随后恢复一致配置。
5. 给 ray/noise 添加小的标准差，采样多帧，比较单次测量与均值。

## 错误分析与挑战
若 CPU 有数据而 GPU 没有，先检查本课日志中的图形上下文和 gpu_laser 插件，不要把无图形窗口等同于不需要渲染设备。若中心距离差一个固定厚度，检查墙的中心位置与表面位置。独立挑战：设置三块不同距离的障碍物，按角度分区报告最近距离，并正确处理无穷值。

## 验收
自动检查真实双路扫描、约 2.9 m 初始距离和墙移动后的约 3.9 m 距离，并恢复场景。人工确认 visual/collision 错配实验以及噪声分析。

不了解扫描消息？[查看 LaserScan 消息定义](https://docs.ros.org/en/noetic/api/sensor_msgs/html/msg/LaserScan.html)。不了解仿真传感器噪声？[查看 Classic 噪声教程](https://classic.gazebosim.org/tutorials?tut=sensor_noise)。
