#!/usr/bin/env python3
import math
from gazebo_msgs.msg import ContactsState
from lab import init, sample, report
init()
msg = sample('/lesson14/contacts', ContactsState, lambda m: any('puck' in s.collision1_name+' '+s.collision2_name for s in m.states), timeout=15)
chosen = [s for s in msg.states if 'puck' in s.collision1_name+' '+s.collision2_name]
assert all('bumper' in s.collision1_name+' '+s.collision2_name for s in chosen), '接触对象不是保险杠'
assert any(len(s.contact_positions) > 0 for s in chosen), '没有实际接触点'
forces = [math.sqrt(s.total_wrench.force.x**2+s.total_wrench.force.y**2+s.total_wrench.force.z**2) for s in chosen]
assert all(math.isfinite(x) for x in forces), '支持力不是有限数值'
assert max(forces) > 0.1, '检测到碰撞但没有有效接触力'
report(contact_pairs=[s.collision1_name+' <-> '+s.collision2_name for s in chosen], force_norm_newton=forces, frame=msg.header.frame_id)
