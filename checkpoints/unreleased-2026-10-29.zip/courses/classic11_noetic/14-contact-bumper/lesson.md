# 14 碰撞保险杠：接触发生了什么

## 项目目标
让一块 1 kg 方块落到蓝色保险杠上。观察接触发生前、冲击期间和静止支撑时的数据，解释为什么“看起来挨着”与“存在接触力”是两件事。

## 先运行，再解释
点击开始实验，Gazebo 自动打开，应用为本课建立独立 ROS 通道。这里先使用准备好的 ROS 观测插件；节点、Topic 和 Master 的原理将在第 22 课系统展开。运行 `rostopic echo /lesson14/contacts`，方块落稳后展开 states。查看 collision1_name、collision2_name、contact_positions 和 total_wrench，不要只数消息条数。

## 必要原理与信息流
碰撞引擎先用 collision 几何判断相交，再由接触求解器计算阻止穿透的约束力。Contact Sensor 订阅指定碰撞体的接触结果，ROS 传感器插件把这些结果包装成 ContactsState。完整路径为：方块位姿与速度 → 碰撞检测 → 接触约束求解 → Contact Sensor → ROS 插件 → 接触消息。距离接近但尚未接触时，不应产生接触点。

本课把 frameName 显式设为 world。接触插件不同字段的参考系不能凭名字猜测，尤其不能把修改消息头当成已经完成坐标变换。碰撞双方的力符号相反；静止时支持力的量级应接近重力，冲击瞬间则可能大得多。

## 文件与关键配置
`world.sdf` 定义蓝色 plate、名称为 bumper_collision 的碰撞体、Contact Sensor 和红色 puck。sensor/contact/collision 必须与所在 link 的碰撞名称一致。`verify.py` 订阅实际数据，等待包含 puck 的接触对，检查接触点与有限的非零力；`lab.py` 用墙钟超时避免暂停仿真后一直等待。

## 实验步骤
1. 预测方块落地前 states 是否为空，再观察。
2. 运行 `python3 drop.py --height 1.8`，重新释放方块，比较冲击与静止输出。
3. 只修改 puck 的 mass 为 2，重启本课仿真，比较静止支持力；形状和落高保持不变。
4. 把方块移出保险杠范围，确认保险杠不再报告它与地面的接触。

## 故障与挑战
把 contact/collision 错写为 visual 的名字，观察“能碰撞但没有传感器结果”的现象。恢复后解释物理碰撞、传感器过滤和消息输出三个环节分别承担什么。独立挑战：增加第二个落块，用名称区分两个接触对象，统计接触事件时要处理同一次持续接触产生的多帧消息。

## 验收
自动验收检查真实碰撞对、接触点和接触力；人工确认落块过程以及质量变化后的量级关系。自动通过不代表完成了事件去重挑战。

不了解接触传感器？[查看 Classic 接触传感器教程](https://classic.gazebosim.org/tutorials?tut=contact_sensor)。想确认消息来源？[查看 Noetic 碰撞插件源码](https://github.com/ros-simulation/gazebo_ros_pkgs/blob/noetic-devel/gazebo_plugins/src/gazebo_ros_bumper.cpp)。
