#!/usr/bin/env python3
"""本课实验工具：用墙钟超时等待真实消息；状态改动由调用者恢复。"""
import copy
import json
import math
import time
import rospy
from gazebo_msgs.msg import ModelState
from gazebo_msgs.srv import GetModelState, SetModelState

def init():
    rospy.init_node("gazeboteach_sensor_check", anonymous=True, disable_signals=True)

def sample(topic, message_type, predicate=None, timeout=12):
    received = []
    sub = rospy.Subscriber(topic, message_type, received.append, queue_size=10)
    deadline = time.monotonic() + timeout
    try:
        while time.monotonic() < deadline and not rospy.is_shutdown():
            while received:
                msg = received.pop(0)
                if predicate is None or predicate(msg):
                    return msg
            time.sleep(0.02)
    finally:
        sub.unregister()
    raise RuntimeError("等待真实数据超时：" + topic)

def collect(topic, message_type, seconds=3.0):
    received = []
    sub = rospy.Subscriber(topic, message_type, lambda m: received.append((time.monotonic(), m)), queue_size=200)
    deadline = time.monotonic() + seconds
    try:
        while time.monotonic() < deadline and not rospy.is_shutdown():
            time.sleep(0.02)
    finally:
        sub.unregister()
    if len(received) < 2:
        raise RuntimeError("有效样本不足：" + topic)
    return received

def state(name):
    rospy.wait_for_service("/gazebo/get_model_state", timeout=10)
    answer = rospy.ServiceProxy("/gazebo/get_model_state", GetModelState)(name, "world")
    if not answer.success:
        raise RuntimeError(answer.status_message)
    result = ModelState()
    result.model_name = name
    result.reference_frame = "world"
    result.pose = copy.deepcopy(answer.pose)
    result.twist = copy.deepcopy(answer.twist)
    return result

def apply(value):
    rospy.wait_for_service("/gazebo/set_model_state", timeout=10)
    answer = rospy.ServiceProxy("/gazebo/set_model_state", SetModelState)(value)
    if not answer.success:
        raise RuntimeError(answer.status_message)

def report(**observations):
    print(json.dumps({"passed": True, "observations": observations}, ensure_ascii=False, indent=2))
