#!/usr/bin/env python3
import argparse
from geometry_msgs.msg import Twist
from lab import init, state, apply
p=argparse.ArgumentParser(); p.add_argument('--height',type=float,default=1.4); args=p.parse_args()
if not 0.4 <= args.height <= 5: p.error('高度需在0.4到5米之间')
init(); target=state('puck'); target.pose.position.x=0; target.pose.position.y=0; target.pose.position.z=args.height; target.twist=Twist(); apply(target)
print('已将方块放到 %.2f m 并清零速度，随后由物理引擎计算自由落体。' % args.height)
