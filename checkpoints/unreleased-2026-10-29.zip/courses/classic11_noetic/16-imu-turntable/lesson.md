# 16 IMU 转台：姿态、角速度与比力

## 项目目标
绿色转台上装有真实 IMU 传感器。给转台一个已知的世界 z 轴角速度，观察陀螺仪、加速度计和姿态四元数三种输出。完成后应能解释：它们不是同一物理量，也不能互相直接替代。

## 必要背景
姿态描述传感器坐标系相对参考系的方向；角速度描述瞬时转动速率，单位 rad/s。加速度计通常测量比力，其重力语义必须结合传感器实现和参考系解释，静止读数不能先验地断言必定全为零。四元数的四个分量也不是四个角度，正常旋转四元数的模长应接近 1。

## 场景与信息流
本课使用一个动态刚体，link/gravity=false 用于避免转台下落，没有用静态模型假装电机转动。`turntable.py` 读取当前模型状态，保留位置和姿态，只设置角速度；之后运动由物理引擎积分。路径为：模型目标角速度 → 刚体运动 → ImuSensor 对姿态/角速度/加速度采样 → gazebo_ros_imu_sensor 插件 → sensor_msgs/Imu。输入命令的世界轴与传感器输出轴只有在特定姿态下才重合。

## 文件与关键配置
`world.sdf` 使用 Classic imu 类型。Noetic 观测插件读取 frameName、updateRateHZ 和 gaussianNoise；它们与传感器本身的 update_rate 共同影响输出。initialOrientationAsReference=false 保留世界参考方向，避免把起始姿态当成零姿态。`verify.py` 设定 0.6 rad/s，等待真实陀螺仪接近此值，检查四元数模长和数据有限性，最终恢复进入验收前的状态。

## 引导实验
1. 执行 `rostopic echo -n 1 /lesson16/imu`，分别辨认三组字段以及 covariance。
2. 运行 `python3 turntable.py --speed 0.6`，预测绕 z 轴旋转时哪些分量显著变化。
3. 改为 -0.6，检查旋转方向和角速度符号。用 `--speed 0` 停止。
4. 把初始姿态绕 x 轴转 90 度，重新分析世界角速度在机体系中的投影，不能继续只看 z 分量。
5. 只调整 gaussianNoise，观察静止样本的离散程度；噪声越大不代表传感器更“真实”，需要与目标硬件指标对应。

## 典型错误与挑战
缺少 frameName 时该 Noetic 插件不能正确完成参数加载；把 update_rate 改高却保留较低 updateRateHZ，也不会得到期望的发布频率。独立挑战：记录两秒姿态，结合角速度预测 yaw 变化，并解释角度环绕或四元数符号变化为什么不等于姿态跳变。

## 验收
自动验收检查真实旋转测量与姿态有效性。加速度重力语义、换坐标轴实验和姿态积分误差需要按记录进行解释。

不了解 IMU 约定？[查看 ROS REP 145](https://github.com/ros-infrastructure/rep/blob/master/rep-0145.rst)。想确认本课插件参数？[查看 Noetic IMU 插件源码](https://github.com/ros-simulation/gazebo_ros_pkgs/blob/noetic-devel/gazebo_plugins/src/gazebo_ros_imu_sensor.cpp)。
