#!/usr/bin/env python3
import copy
import math
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Imu
from lab import init, sample, state, apply, report
init()
original = state('turntable')
try:
    turning = copy.deepcopy(original); turning.twist=Twist(); turning.twist.angular.z=0.6; apply(turning)
    msg=sample('/lesson16/imu',Imu,lambda m: abs(m.angular_velocity.z-0.6)<0.08)
    q=msg.orientation
    norm=math.sqrt(q.x*q.x+q.y*q.y+q.z*q.z+q.w*q.w)
    assert abs(norm-1)<0.01, '四元数未归一化'
    assert all(math.isfinite(v) for v in [msg.linear_acceleration.x,msg.linear_acceleration.y,msg.linear_acceleration.z]), '加速度无效'
    assert msg.header.frame_id=='imu_link', 'IMU参考系不匹配'
    report(angular_z_rad_s=msg.angular_velocity.z, quaternion_norm=norm, specific_force_xyz=[msg.linear_acceleration.x,msg.linear_acceleration.y,msg.linear_acceleration.z], frame=msg.header.frame_id)
finally:
    apply(original)
