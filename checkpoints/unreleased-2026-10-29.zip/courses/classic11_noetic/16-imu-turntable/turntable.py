#!/usr/bin/env python3
import argparse
from geometry_msgs.msg import Twist
from lab import init, state, apply
p=argparse.ArgumentParser(); p.add_argument('--speed',type=float,default=0.6); a=p.parse_args()
if not -3 <= a.speed <= 3: p.error('角速度需在-3到3 rad/s之间')
init(); s=state('turntable'); s.twist=Twist(); s.twist.angular.z=a.speed; apply(s)
print('位置和姿态保持不变，世界z轴角速度设置为 %.3f rad/s；后续由物理引擎积分。' % a.speed)
